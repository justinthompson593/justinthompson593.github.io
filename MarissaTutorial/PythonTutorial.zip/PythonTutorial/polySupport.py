#! /usr/bin/env python

#PLEASE read all the way through this guy until the End Of File. 

import numpy as np
import scipy.misc as sm

########################################################
# makeCoefsByFormula( whichFormula, orderOfPoly )
#
#	Constructs an array of coefficients to input into
#	the numpy function "poly1d".
#
# INPUTS:	whichFormula = 	integer from the set {0,1,2}
#							0 -> coefs for f(x) = e^(x)
#							1 -> coefs for f(x) = sin(x)
#							2 -> coefs for f(x) = cos(x)
#
#			orderOfPoly  =	The value of the largest 
#							exponent to calculate. Note
#							that a 0th order poly is 
# 							kinda worthless.
#
#
# OUTPUTS:	coefsOut     =	the coefficients for the 
#							function selected by 1st 
#							input, "whichFormula"
#
#
# Authors: Justin Thompson, Marissa Dominguez 
########################################################
def makeCoefsByFormula( whichFormula, orderOfPoly ):
	
	#If our poly is order 2, then it looks like this:
	#		P(x) = 2*x^2 -4*x + 3
	#So the coefficients we want are [2, -4, 3]
	#When the order is 2, we want 3 coefs. 
	#When the order is k, we want k+1 coefs.
	#It's always a good idea to initialize an array
	#(which we do below) with the full number of 
	#places for data. If you don't, the computer has
	#to continually update the size of the variable
	#you're trying to make. No like; bad medicine. 
	#Below when we make our output for this function
	#(the array we return), we want to tell the 
	#computer how large the array will be. Since we
	#already know that we need (orderOfPoly + 1) 
	#places in our array, let's store that number 
	#for use below.
	n = orderOfPoly + 1
	
	#Since we have to output something, now's a good
	#time to declare what we need. Since the OUTPUT of
	#this function will be the INPUT to the numpy
	#function poly1d, a quick search for "numpy poly1d"
	#tells me that we need some kind of array that has
	#the same length as the number of coefficients we
	#want. This is a way to make an array named 
	#"coefsOut" that has n zeros. Recall that "n" is 
	#now the number of coefs we want. This is the 
	#array we'll return once we compute the coefs.
	coefsOut = np.zeros(n)
	
	
	#Here's a cool trick: 
	
	#As I'm writing this, I know that the task of 
	#filling up a vector with coefficients is rather general. 
	#That is, all I have to do is change the formula which calculates
	#the individual coefficients, and the overall 
	#structure stays the same. (You still loop through
	#something n times and assign n values to a vector or array.) 
	#It easily lends itself to cutting & pasting. 
	
	#I also know that explicitly writing a formula for the coefficients
	#is no trivial task! Remember how many calculations we had
	#to do in order to get the coefficients,
	#	1 + x + (1/2!)x^2 + (1/3!)x^3 + ... + (1/n!)x^n 
	#for our nth order approximation to f(x) = e^(x) ?	
	#Since it's not easy to just input a new FORMULA,
	#maybe I can make this function (and it's skeleton) 
	#more useful by calculating a different formula,
	#copying the template, pasting it, and filling it in with
	#new formula. Not too hard. 
	
	#This is where the trick comes in. I'll just use an "if
	#statement" here with some kind of "code" that we can 
	#choose when we call the function. Our "code" could be
	# 0 means f(x) = e^(x)
	# 1 means f(x) = sin(x)
	# 2 means f(x) = cos(x)
	
	#It's also easy to just 
	#add on below if you come up with a new function. (When 
	#you do that, be sure to update the documentation at 
	#the top of the function. You'll be sorry if you don't!)
	
	#The only problem is that I don't remember how to write 
	#an "if statement" in Python. Hmm. Maybe if I search
	#"python 2.7 if statement" I'll find something. 
	#
	#{ Oh, there are different versions of python out there with different
	#  syntaxes...syntaxae...syntaxi? We happen to be using 2.7.          }
	#
	#The search was too easy. We can do this:
	#
	#		if myInput == 0:
	#			doStuffWeChooseToDoWhenWeMakeTheInputZero()
	#
	#			return coefsOut
	#
	#		elif myInput == 1:
	#			doThatOtherStuffWeChooseToDoWhenWeMakeTheInputOne() 	
	#
	#			return coefsOut
	#
	#		else:
	#			print 'Dude, we only wrote 2 functions!'
	# 			return 0 
	#
	#And then, if we want to add something, it's as easy as
	#inserting a new "elif myInput == k" and so on. 
	#
	#Again, MAKE SURE YOU UPDATE THE DESCRIPTION ABOVE when you update your code.
	#The idea here is that we're doing the same basic thing
	#in each of these cases. It's easy to copy a block, paste
	#it, and start changing things until you get something
	#completely different. 
	
	
	
	#I've added a line before and after
	#each if statement case. It can get quite confusing when you
	#start adding lines and lines of code. This way you know when
	#each case begins and ends. Check it out
	
	"""
	#######################################################
	# CASES
	#
	# 	whichFormula == 0  ->  f(x) = e^(x)
	#	whichFormula == 1  ->  f(x) = sin(x)
	# 	whichFormula == 2  ->  f(x) = cos(x)
	#######################################################
	"""
	
	#BEGIN f(x) = e^(x)-----------------------------------------|
	if whichFormula == 0:
		#then we want make the coefficients for
		#f(x) = e^(x)
		
		#Remember how we got them? (REVIEW THIS NOW!!!)
		#The only difference between what we did before
		#and what we're doing now is that we want the 
		#coefficients in the OPPOSITE order. The C++
		#function we wrote (polyval) made a vector of coefs 
		#[a0, a1, a2, ... an] for the polynomial
		#	a0 + a1*x + a2*x^2 + ... + an*x^n
		#The documentation I read for poly1d says it
		#takes them in the opposite order. So it wants
		#the the coefficient vector like this:
		#	 [an, an_1, ..., a1, a0].          
		# No problem:
		for i in range(0, n):
			#This way, "i" goes through 0, 1,...,(n-1)
			#Remember that we want to start at 
			#"orderOfPoly" and step down since our polynomial is 
			#
			#	an_minus1*x^(orderOfPoly) + an_minus2*x^(orderOfPoly - 1) + ... +   a2*x^(2)  +  a1*x  +  a0
			#
			#We want:
			#
			#coefsOut = [an_1, an_2, ..., a2, a1, a0]
			#
			#All of these (n-1)'s are getting confusing. 
			#This is why I chose to make one of the INPUTS
			#the order of the poly, so there's no question
			#which needs to be the first coefficient in the 
			#output. The first entry, the one with index 0, 
			#should be the coefficient with x^(orderOfPoly)
			coefsOut[i] = 1.0/ sm.factorial(orderOfPoly - i)
			
			#Above, I did "orderOfPoly - i" because I know
			#that i starts at i = 0. Since we are computing
			#the coefficient for x^(orderOfPoly), this will
			#give us:
			#coefsOut[0] 	= 1 / orderOfPoly!
			#coefsOut[1] 	= 1 / (orderOfPoly - 1)!
			#...
			#coefsOut[n-3]	= 1 / (orderOfPoly - [n-3])!
			#coefsOut[n-2]	= 1 / (orderOfPoly - [n-2])!
			#coefsOut[n-1]  = 1 / (orderOfPoly - [n-1])! #*** remember that for range(0,M), it goes 0,1,...,M-3,M-2,M-1 and never gets to M!
			
			#
			#But since n = orderOfPoly + 1, we have 
			#
			#coefsOut[0] 	= 1 / orderOfPoly!
			#coefsOut[1] 	= 1 / (orderOfPoly - 1)!
			#...
			#coefsOut[orderOfPoly + 1 - 3]	= 1 / (orderOfPoly - [orderOfPoly + 1 - 3])!
			#coefsOut[orderOfPoly + 1 - 2]	= 1 / (orderOfPoly - [orderOfPoly + 1 - 2])!
			#coefsOut[orderOfPoly + 1 - 1]  = 1 / (orderOfPoly - [orderOfPoly + 1 - 1])!
			#
			#which simplifies to
			#
			#coefsOut[0] 				= 1 / orderOfPoly!
			#coefsOut[1] 				= 1 / (orderOfPoly - 1)!
			#...
			#coefsOut[orderOfPoly - 2]	= 1 / (2)!
			#coefsOut[orderOfPoly - 1]	= 1 / (1)!
			#coefsOut[orderOfPoly - 0]  = 1 / (0)!
			#
		#So coefsOut = [1/orderOfPoly!, ... , 1/3!, 1/2!, 1/1!, 1/0!],	
		#and that's what we want to return!
		return coefsOut
	#END f(x) = e^(x)--------------------------------------------------|
		
		
			
	#BEGIN f(x) = sin(x)-----------------------------------------------|		
	elif whichFormula == 1:
		
		#Your code goes here ;-)
		
		print 'WARNING: Option 1 has not been defined. Returning 0.'#change this!
		return 0    #change this! 
	#END f(x) = sin(x)-------------------------------------------------|		
		
	
	#BEGIN f(x) = cos(x)-----------------------------------------------|		
	elif whichFormula == 2:
		# Then let's choose to make coefficients for
		# f(x) = cos(x)
		
		#I'll fill this one in after you finish the 
		#code for f(x) = sin(x). They're VERY similar.
		#If I wrote out a formula for cos(x), it would 
		#be WAY too easy for you to figure out how to 
		#program the coefs for sin(x)  ;-)
		
		print 'WARNING: Option 2 has not been defined. Returning 0.'
		return 0     
	#END f(x) = cos(x)-------------------------------------------------|
		
		
		
	#BEGIN otherwise---------------------------------------------------|	
	else:
		print 'Dude, there are only 3 options: 0, 1, or 2'
		print 'This works: "makeCoefsByFormula(2, M)"'
		print 'But this will not: "makeCoefsByFormula(3, M)"'
		print 'WARNING: Returning 0.'
		return 0
	#END otherwise-----------------------------------------------------|
	
	
	"""
	#######################################################
	# END CASES
	#######################################################
	"""
	
	
########################################################
# END makeCoefsByFormula( whichFormula, orderOfPoly )
########################################################	
	
	
	
	
	
	

# It depends on the editor you're using, but with mine

"""
the 3 quotes [3*(")] comments are red
"""

# and the inline comments (#) are green. This hints at a 
# handy way of organizing your code. I.e.

########################################
#FUNCTION organizingExampleFunction(...) 
#
# Returns your position in 5-dimensional 
# "space"
########################################
def organizingExampleFunction(yourLatitude, yourLongitude, yourElevation, currentTime, currentTemperature):
	
	# Globals
	loopCounter = 0
	
	"""
	BEGIN Loop 1------------------------------------|
	"""
	for i in range(0, 3):
	
		#BEGIN Loop 2-------------------------------|
		for j in range(0, 3):
		
			"""
			BEGIN Loop 3----------------------------|
			"""
			for k in range(0,3):
				
				#BEGIN Loop 4-----------------------|
				for l in range(0,3):
					loopCounter += 1
					print 'Loop number', loopCounter
				#END Loop 4-------------------------|
	
			"""
			END Loop 3------------------------------|
			"""
		#END Loop 2---------------------------------|
	
	"""
	END Loop 1--------------------------------------|
	"""
	return np.matrix([yourLatitude, yourLongitude, yourElevation, currentTime, currentTemperature])
###################
#END orgnzExampFcn
###################	
	


# It's fine to do it while you're messing around, but it's not a good idea
# to keep it like that. You should go through and change them to inline comments
# (that is, the green ones with the # symbols like these) if you plan on
# doing anything with that code.
#
# Check out http://legacy.python.org/dev/peps/pep-0008/#block-comments
# and then http://legacy.python.org/dev/peps/pep-0257/ if you want to know
# the right way to do it. (You don't have to, but I never wrote this!)
#
# End Of File  ...  E.O.F  ...  EOF	
#eof