#! /usr/bin/env python


import numpy as np


n = 240
m = 320

N = n*m

filler = np.zeros(N)
M = np.matrix(filler)
print 'M =', M

num

M.resize(n, m)

print 'M =', M