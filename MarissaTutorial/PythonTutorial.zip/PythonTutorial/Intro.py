#! /opt/bin/env python

"""
Intro.py

Hey there! Python is MUCH easier to get the hang of than
C++. Since iPython is so friendly I won't be going into 
as many technicalities with the coding. If you're not sure how
something works, you can just type it line by line into iPython 
and figure out a lot on your own with the Tab key.

I'll still go into detail about the concepts and whatnot, though.

"""

#"import numpy as np" lets us use the entire numpy library. Alls we gotta do 
#is write "np." and hit Tab to see options. For a more thorough treating of 
#the functions, just Google "numpy anything" and you'll get some good info.
import numpy as np

#You'll notice the file "introSupport.py" in Dropbox/ForMarissa/Python.
#Go ahead, open it up, and read it. All of it.
from introSupport import *


"""
Welcome back! Did you read all the way through "introSupport.py"? I mean
ALL the way through to the very VERY end??

Okay.

Writing "import *" above let's us call all of the functions in 
introSupport.py by name. With numpy, we imported it as "np". 
To access those functions, we have to write "np.someNpFunction(x,y...etc"
Why would we want to do these two differently?

Well, if we did write "from numpy import *", then every single function 
defined in numpy comes up by name. Suppose you wrote a function called "poly"
and wanted to use it. It just so happens that numpy also has a function
called "poly". Bad medicine. (I don't know why I've adopted that phrase. 
The Simpsons, maybe?) Anyway, numpy has a TON of functions and I frankly
don't want to search through the entire list to make sure we don't have 
any name conflicts. And we haven't even considered what might happen when
we start importing other modules. Bart no like. Bad medicine. Yeah, it was
the Simpsons. 

I wrote "from introSupport import * " because I know that the names of
everything in there were UNIQUE enough that there couldn't be any 
conflict. I mean, if numpy DID have a helloFunction2()...

"""


#Suppose we had done this:
# In [n]: %run Intro.py
#Well, just like in introSupport.py, it would be like writing everything
#that's not commented out line by line:
#
# In [n+1]: import numpy as np
#
# In [n+2]: from introSupport import *
#
#Then we'd go on similarly. This file is set up like this:
#
#	"""
#	Intro.py
#	...
#
#	#Place to import stuff
#	import X
#	...
#
#	#Place to define functions
#	def func1()
#	def func2()
#	...
#
#	#Place to define an executable 
#	def myExecutable()
#
#	#instructions if someone runs this file
#	if __name__ == '__main__':
#	...
#
#And here at the very end, we call "myExecutable()" so
#it gets carried out when someone runs the file. If this 
#file ISN'T run and you'd still like to use it's functions
#in ANOTHER file, you can just do "from Intro import *"
#
#Read along and know that the computer is just going along
#with you, defining all of these functions until, at the
#end, we tell it to actually do something. After you've read all
#the way through, see if you can predict what the output will be
#when it runs. Trace the functions through step by step, the way
#the computer does. But first, read on.





############################################
# FUNCTION: helloFunction()
#
# When called, it prints 'hello world'.
# Pretty useless function.
############################################
def helloFunction():
	print 'hello world'



###################################################################
# FUNCTION: addNewElementToVector(vector, newElement)
#
# INPUTS:	vector 	   = the vector (array, or whatever)
#							you want to add entries to
#			(Yeah, a preposition is what that last statement ended with.)
#
#			newElement = the new value you want to
#							add to your vector
#
# This function illustrates that you can have a 
# function which technically has no "OUTPUT" because
# it doesn't "return" anything. But we we can modify 
# an input in the same way as "passing by reference"
# in C++. Only with Python, we don't need the "&" 
# operator. Python is so "high level" that we don't 
# need to specify that we're modifying vector, and hence
# need access (&) to the address. In Python, we don't 
# even need to tell it that we're giving it a vector (or
# array, or whatever) because it infers it from context.
# I could have called it "justin" instead or:
#
#	def addNewElementToVector(marissa, dominguez):
#		marissa.append(dominguez)
#
# Just as long as we give this function an array we're good.
# One of the many ways to make something an array is to 
# initialize it as:
#		myArray = []
# You'll see an example below in main.
# Notice though, that this is a rather useless function!
# I mean, it takes one line to write. It would be very
# inefficient to write this way: just throw it in the code!
#################################################################
def addNewElementToVector(vector, newElement):
	vector.append(newElement)



#################################################################
# FUNCTION: runIntro()
#
# The main executable. This file is set up to run this function
# if someone runs this file as main like this:
#
#  In [n]: %run Intro.py
#
#################################################################
def runIntro():

	#Note that \n is the command for a new line
	print '\nIn runIntro()\n'
	
	print 'First, we call a function defined in this file.'
	print 'Calling helloFunction().\n'
	
	helloFunction()
	
	print '\nDone with helloFunction(). Back in runIntro().\n'
	
	
	
	print 'Initializing an empty array.'
	myVec = []

	#We'll print it now just to see what it's
	#like before and after we fill it. 
	print 'myVec = ', myVec
	
	#And we'll ask how long to make it.
	print '\nHow long do you want your vector to be? '
	print 'Note that when you hit enter, there will'
	print 'a long output. Youll have to scroll up'
	print 'to get back to here.\n'
	usrIn = input('Enter an integer: ')
	
	
	print '\nThis loop could easily have been turned'
	print 'into a function which takes usrIn as'
	print 'an input. But thats for another day.\n'
	
	print '\nEntering loop to add elements...\n'
	for i in range(0, usrIn):
		print 'Now were adding ', i, 'to myVec'
		addNewElementToVector(myVec, i)
	
	print '\nNow that were done adding, lets look at our vector/array'
	print 'myVec = ', myVec
	
	print '\nWe can also use the functions from introSupport.py\n'
	print 'Calling helloFunction2() from introSupport.py\n'
	
	helloFunction2()
	
	print '\nDone with helloFunction2(). Back in runIntro().'
	
	print '\nAssigning the output of supportFunction(0,7,5) to'
	print 'the variable "myVar"\n'
	myVar = supportFunction(0,7,5)
	
	print '\nDone with supportFunction(0,7,5). Back in runIntro()'
	print 'Check the output:'
	print 'myVar = ', myVar
	
	print '\nCalling supportFunction2(0,7,5)'
	print 'Not assigning it to anything. It will just run.\n'
	
	supportFunction2(0,7,5)
	
	print '\nDone with supportFunction2(0,7,5). Back in runIntro()'
	
	print '\n\nrunIntro() has finished with exit code: 0\n'
	return 0





if __name__ == '__main__':
	print '\n'
	print '***************************************************'
	print '      Running Intro.py as main'
	print '***************************************************'
	print '\nCalling runIntro()\n'
	runIntro()

#Now try to predict what the output will be before you 
# In [k]: %run Intro.py
#After you've played with all of this (and don't give it
#a number bigger than 1000 when it asks!) and FULLY understand
#what's going on here, move on to Polynomials.py 
#ENJOY!
	
	
	
	
	