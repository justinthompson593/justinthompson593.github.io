#! /usr/bin/env python


#PLEASE read to the end before running!

"""
Polynomials.py

Plots a function in blue and it's nth order polynomial 
approximation in red on the same plane.
"""



#Import stuff we'll need to do math and plot
import numpy as np
import scipy.misc as sm
import matplotlib.pyplot as plt

#Importing all the functions from polySupport.py. Now would be a 
#good time to read through polySupport.py. 
from polySupport import *

###########################################################################
# 					GLOBALS
###########################################################################
#Choose bounds for your plot. "lowerPlotLimit" is the 
#left-most value on the x axis we want to plot, and 
#"upperPlotLimit" is the right-most. Let's leave them
#at -3 and 3 for now.
lowerPlotLimit = -3
upperPlotLimit = 3
#Now when we plot, our x axis will be -3 <= x <= 3


#choose number of points to plot
numPtsToPlot = 100
#Remember that when we call plt.plot(x,y), the 
#function says, okay, the first array you give me is the 
#x-axis, and the second is the y axis. The first value in 
#the vector, x, is -3. So, x[0] = -3. That value corresponds
#to y[0] and x[1] = 3 corresponds to y[1]. This is why, 
#the arrays x and y must have the same length. 

#If we chose numPtsToPlot = 2, then the computer would just plot
#two points. It would then draw one line connecting the two points. 
#If numPtsToPlot = 3, It would draw 3 points, and connect them with 2
#straight lines. 

#By having numPtsToPlot = 100, we ensure that the computer will draw
#enough points so that we don't end up with a stupid line. The computer
#will draw straight lines between the points, but there will be enough
#of them that it'll look like a smooth curve to us.


#order of our approximation
orderPoly = 4

#We're going to make a polynomial, of order 4, which approximates
#the function f(x) = e^(x). From our earlier work, we know that the
#4th order polynomial approximation is given by:
#
#	P4(x) = 1 + x + (1/2!)x^2 + (1/3!)x^3 + (1/4!)x^4
#
#		  = 1.0 + 1.0x + 0.5x^2 + 0.1667x^3 + 0.04167x^4
#	
#And since we know that np.poly1d wants these coefficients in 
#descending order,
#
#	P4(x) = (1/4!)x^4 + (1/3!)x^3 + (1/2!)x^2 + x + 1 
#
#		  = 0.04167x^4 + 0.1667x^3 + 0.5x^2 + 1.0x + 1.0
#
#So we need to construct the vector:
#
#	[1/4!, 1/3!, 1/2!, 1/1!, 1/0!] = [0.041667, 0.16667, 0.5, 1.0, 1.0]
#
#But we've imported makeCoefsByFormula from polySupport.py. Since the
#coefficients we want to construct are the ones for f(x) = e^(x), the 
#documentation in polySupport.py tells me to make the first input to 
#"makeCoesByFormula" a zero. Also, "orderPoly" is the second input. 
#That's what we wrote below.





###################################################################
#	Main executable
#
# Note that this time, we don't have if __name__ ... at the bottom.
# When you run this, it simply puts each not commented line into
# iPython. Since that's the case, there's no use defining a 
# function to hold our main executable. For the purposes of THIS
# file, it's enough to run it as is. 
###################################################################
#Make coefficients
coeffs = makeCoefsByFormula(0, orderPoly)
#Now, the vector "coefs" should be [0.041667, 0.16667, 0.5, 1.0, 1.0]
#because that's how we defined it in polySupport.py


#Make our (orderPoly)th order polynomial approximation
P = np.poly1d(coeffs)
#This constructs a numpy polynomial called "P". If you
#Google search "numpy poly1d", you'll see what's going on.
#P basically acts like a function now. But it has some
#other nice features too. We can print P all pretty.


#Check it out:
print 'P(x) =', '\n',P

#Setup plot
xAxisToPlot = np.linspace(lowerPlotLimit, upperPlotLimit, numPtsToPlot)

#with lowerPlotLimit = -3, upperPlotLimit = 3, and numPtsToPlot = 100,
#this makes "xAxisToPlot" a vector with 100 entries which starts at 
#-3, and makes 99 equally-spaced steps out to 3. For example, doing
#
#	xAxis = np.linspace(0,9,10) 
#
# would give us
#
#	xAxis = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
#
# and
#
#	xAxis = np.linspace(0,1,101)
#
# would give us
#
#	xAxis = [0, 0.01, 0.02, ..., 0.99, 1]
#
# Since we defined lowerPlotLimit = -3, upperPlotLimit = 3, and
# numPtsToPlot = 100, we have
#
#	xAxisToPlot = np.linspace(-3, 3, 100)
#				= [-3, -2.939, -2.878, ..., 2.878, 2.939, 3]


#We want to see what our approximation, P(x), looks like 
#when we plot it on top of the actual function we are 
#trying to approximate. First, let's make a vector which
#has the true values of f(x) = e^(x).

#The true function
F = np.exp(xAxisToPlot)
#By giving the "np.exp()" function a vector, it knows that we 
#want it to return a vector of the same size. Since
# xAxisToPlot = [-3, -2.939, -2.878, ..., 2.939, 3], this function says,
#
#	"Okay. They gave me a vector of length 100. So the output, F, will
#	also be a vector of length 100. The first value of F that I assign,
#	F[0], will be the value of exp(xAxisToPlot[0]) = exp(-3) = 0.0498.
#	The next value that I assign, F[1], will be the value of
#	exp(xAxisToPlot[1]) = exp(-2.939) = 0.0529. And so on,
# 	In the end, we have
#
#	F[0]  = e^(xAxisToPlot[0]) = e^(-3)     = 0.0498 
#	F[1]  = e^(xAxisToPlot[1]) = e^(-2.939) = 0.0528 
#	F[2]  = e^(xAxisToPlot[2]) = e^(-2.878) = 0.0562 
#	...
#	F[97] = e^(xAxisToPlot[97]) = e^(2.878) = 17.791 
#	F[98] = e^(xAxisToPlot[98]) = e^(2.939) = 18.903 
#	F[99] = e^(xAxisToPlot[99]) = e^(3)     = 20.086 

#Try this on your own! Go to iPython and do something like:
# In[k]	 : import numpy as np
# In[k+1]: xAxis = np.linspace(0,7,20)
# In[k+2]: xAxis
# ***it will display xAxis after you hit return***
# In[k+3]: y = np.sin(xAxis)
# In[k+4]: y
# ***it will display y after you hit return***

#Our polynomial approximation
#Recall that P now has the coefficients, coefs = [0.041667, 0.16667, 0.5, 1.0, 1.0]
Fappx = P(xAxisToPlot)
#This does the exact same thing as np.exp(xAxisToPlot), but
#with our polynomial instead of the exponential function. 
#Now, we have
#
#	Fappx[0]  = P(-3)     = 0.04167(-3)^4     + 0.1667(-3)^3     + 0.5(-3)^2     + 1.0(-3)     + 1.0
#	Fappx[1]  = P(-2.939) = 0.04167(-2.939)^4 + 0.1667(-2.939)^3 + 0.5(-2.939)^2 + 1.0(-2.939) + 1.0
#	Fappx[2]  = P(-2.878) = 0.04167(-2.878)^4 + 0.1667(-2.878)^3 + 0.5(-2.878)^2 + 1.0(-2.878) + 1.0
#	...
#	Fappx[97] = P(2.878)  = 0.04167(2.878)^4 + 0.1667(2.878)^3 + 0.5(2.878)^2 + 1.0(2.878) + 1.0
#	Fappx[98] = P(2.939)  = 0.04167(2.939)^4 + 0.1667(2.939)^3 + 0.5(2.939)^2 + 1.0(2.939) + 1.0
#	Fappx[99] = P(3)      = 0.04167(3)^4     + 0.1667(3)^3     + 0.5(3)^2     + 1.0(3)     + 1.0

#Investigate how this all works:
#If you haven't already imported numpy as np, do it, then
# In[j]  : myCoefs = [1.0, 2.0, 3.0, 4.0, 5.0]
# In[j+1]: myPoly = np.poly1d(myCoefs)
# In[j+2]: print myPoly
#***It'll print it all purdy lookin' like this***
#
#           4     3     2
#        1 x + 2 x + 3 x + 4 x + 5
#
#See if you can make a poly which will print this:
#
# 		   7     5     3   
# 		7 x - 5 x + 3 x - 1 x
#
#Look at the VERY end of this file for the answer





#Here's how we tell it to plot two things:
#
#plt.plot(firstXAxis, firstYValues,howToPlot, secondXAxis, secondYValues,howToPlot)
#
#The first two inputs are read as the x axis and the 
#function values to plot (the y values). Then we type
#'b-', which tells the computer to plot the true function, F,
#as a blue line. The last 3 inputs tell it to plot Fappx on the 
#same axis, but to make it a red line, 'r-'.
plt.plot(xAxisToPlot,F,'b-',xAxisToPlot,Fappx,'r-')
plt.title('Fourth order approximation of f(x) = e^(x) shown in red')
#Now the plot object (called "plt" here) is loaded 
#and ready with all the data we gave it. Let's take
#a look:
plt.show()


#This plot will stay on the screen until you close the window
#by clicking "x" or whatever in the corner which closes windows.
#When you do that, this code below will execute. 



for j in range(1,10):
	
	#When this starts, j = 1. So here,
	cs = makeCoefsByFormula(0, j)
	
	#it makes the first order coefficients:
	#so cs = [1, 1]

	P = np.poly1d(cs)
	#Since cs = [1, 1] the first time, now
	#P(x) = x + 1
	
	#we define the interval on which we evaluate the functions
	x = np.linspace(lowerPlotLimit, upperPlotLimit, numPtsToPlot)
	
	#Then evaluate the two functions at all the points
	#on the x axis we care about.
	F = np.exp(x)
	Fa = P(x)
	#Now F (the true value) and Fa (the approximation) are
	#full of the 100 values evaluated on the x axis
	
	#So we plot them in blue and red, as before.
	plt.plot(x,F,'b-',x,Fa,'r-')
	
	#Here we make a title on the plot so we know which 
	#order approximation we're using
	titleStr = 'Showing the '
	titleStr += str(j)
	titleStr += 'th polynomial approximation in red'
	plt.title(titleStr)
	
	#see below for this guy
	plt.axis([lowerPlotLimit, upperPlotLimit, np.exp(lowerPlotLimit)-2, np.exp(upperPlotLimit)])
	
	#On your iPython terminal, the formula for our 
	#approximation, P(x), is displayed all pretty. You
	#can look at the formula on the terminal while the
	#graph is plotted with a nice title in your plotting
	#window. 
	print 'P(x) = '
	print P
	
	#finally, we show the plot
	plt.show()
	
	#Note that this is the end of the "for j in range(1,10)" loop.
	#So now, the program will wait until you close the current window.
	#Once you do, it will go back to the beginning of this loop,
	#it will increment j so that j = 2, do all the calculations and 
	#finally show the plot. Once you close that window, it'll run
	#through with j = 3, plot it and wait until you close the window. 
	#And so on until you close the window which says "Showing the
	#9th polynomial approximation in red." Once you close that, this 
	#program will end. Go ahead and run it. Before you do, it's worth noting that
	#each time it plots, the x axis will be the same, but the y axis won't
	#be. The way it's set up now, it will show a different span for y. 
	#For instance, if you plotted y = x + 1 on the interval 0 <= x <= 1, 
	#the minimum y value it would plot would be 1 since y is the smallest
	#value when x = 0, 
	#	y = x + 1 = 0 + 1 = 1
	#and y is largest when x = 1,
	# 	y = x + 1 = 1 + 1 = 2.
	#The plot function will make sure you can see all of the function y
	#you want to see, so the y axis will range from 0 to 1 in this case. 
	#Since we're changing the value of P(x) in each loop, each time there
	#may be different minimum and maximum values. The display range for
	#the y axis may change on each new window. To prevent that from happening,
	#we set the axis to be the same each time in the loops. Note that we
	#made it general, that is, the region we plot each time depends only
	#on the values we chose at the very beginning. This way, if we want to
	#check out what happens when we plot it on another interval (ahem), all
	#we have to do is change two values instead of A LOT of them throughout 
	#this file. 
	

	
	
	#After you've run this and you feel like you have the hang of it,
	#go to the beginning and change lowerPlotLimit to -10 and 
	#upperPlotLimit to 10. Notice how much worse the approximations are?
	#You'll have to use a larger-ordered approximation in order to get 
	#decent values farther away from the initial point, x0 = 0. (Remember that
	#x0 = 0 is where we evaluated all of the derivatives we took when we
	#found this formula.) Change the end value in range (from "for j
	# in range(1,10)" )  from 10 to a larger number. How large do you have
	#to make it before your red approximation looks good enough on the 
	#interval -10 <= x <= 10 ? 


"""
Answer for:

 		   7     5     3   
 		7 x - 5 x + 3 x - 1 x


In[m]  : import numpy as np                 (if you haven't already)
In[m+1]: cfs = [7.0, 0, -5.0, 0, 3.0, 0, -1.0, 0]
In[m+2]: ply = np.poly1d(cfs)
In[m+3]: print ply
   7     5     3   
7 x - 5 x + 3 x - 1 x

"""