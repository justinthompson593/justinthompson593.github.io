#! /usr/bin/env python



#If you're reading this, then you read lines 1 through 20 in 1Intro.py.



#Again, we may want to use
import numpy as np


############################################
# FUNCTION: helloFunction2()
#
# INPUTS:	none
#
# OUTPUTS:	none
#
# Illustrates how we can define a function
# in one file, and use it in another.
# When called, it just prints stuff.
############################################
def helloFunction2():
	print 'Hi!'
	print 'This function was defined in introSupport.py'





############################################
# FUNCTION: supportFunction(x,y,z)
#
#Pretty much useless. I just thunk it up.
#But do read through it to understand what's
#going on. You can always check out what's 
#happening in a loop by just typing it into
#the command line repeatedly. For the loop
#below, you can just get on iPython, type
# "a = []", hit return. Then type, 
#"a.append(7)", hit return. If you enter "a"
#and hit return, you'll see that 7 was added
#to the empty vector. Hit the up arrow twice
#to bring "a.append(7)" back up. Hit return. 
#This is the same thing that's going on in 
#the for loop. It just appends some number
#over and over. Python is cool 'cause you
#can investigate what's going on one step at
#a time. 
############################################
def supportFunction(x,y,z):
	print 'in supportFunction(x,y,z)'
	print 'you gave me ',x,y,z
	V = []
	for i in range(0,z):
		V.append(x)
		V.append(y)
	print 'Just made a vector V = ', V
	print 'Let''s return it'
	return V	
		
		
############################################
# FUNCTION: supportFunction2(a,b,c)
#
#See "supportFunction" above.
############################################		
def supportFunction2(a,b,c):
	print 'This is supportFunction2(a,b,c)'
	print 'It does the same thing as supportFunction(x,y,z)'
	print 'The only difference is that we initialize the'
	print 'vector to the size we know it will be first.'
	print 'You gave me' ,a,b,c
	W = np.zeros(2*c)
	for j in range(0,c):
		W[2*j] = a
		W[2*j+1] = b
	print 'Just made a vector W = ', W	
	print 'Let''s return it'
	return W
	
	
############################################
# FUNCTION: supportFunction3()
#
#Even more useless.
############################################		
def supportFunction3():
	print 'support 3!'


############################################
# FUNCTION: 
############################################	
def supportFunction4():
	print 'I quit.'		
		

"""		
This is where it gets interesting. Here at the bottom,
we have an if statement asking if __name__ is __main__.
Huh? Well, this isn't really a runable file. It just has
a bunch of definitions. If we typed in each line of this
file, one by one, into the command line in iPython, well
nothing would happen. We'd have some functions we could use
but no calculations were made. If someone did run this file,
the computer would, for the time being, give it the name "main".
Each file that our program uses (like ALL the files from numpy
when we "import numpy"). But the one we tell to %run, it
thinks of as __main__. So below here, if someone DID type

In[k]: %run introSupport.py

and hit return, then the computer would say, 

		"oh, 'introSupport.py' is like, my main job right now. 
		 Dude, I'm calling it __main__."
  
Then it would go to the top of this file and say, 

		"ah, '#! /usr/bin/env python'?! We're doing Python?! 
		 Sweet. I'm 'unna import me some numpy and call it 
		 np. Then I'm defining this function as..." and so on.

When it gets down to " if __name__ == '__main__' ", it goes,

		*Gasps* 
		"This file IS __main__! That's True! Welp, since it's True, I'd 
		 better do whatever's indented up under the ":"
		 
And it goes on to print the last 4 lines. 		  

"""	


if __name__ == '__main__':
	print 'introSupport.py was run as main'
	print 'It looks like nothing happened, right?'
	print 'Type "supportF" and hit Tab'
	print 'We see that the functions defined here are now available to use'

# Go ahead and try this. Make sure you've done 
#
# In[k]: cd ~/Dropbox/ForMarissa/Python
#
# or whatever the path is before entering 
#
# In[k+1]: %run introSupport.py
#
#otherwise, iPython won't be able to find the file.
#If you can't recall any of this, Google "Unix cd command" or just ASK YONATAN! (He's awesome.)
#
#After running this file, all of the functions are available to you from the 
#command line in iPython. When you %ran this file, it was as though you just
#typed all of the definition into iPython line by line:
#
# In [1]: import numpy as np
#
# In [2]: def helloFunction2():
#   ....: print 'Hi!'
# 	....: print 'This function was defined in introSupport.py'
#   ....: <This is where you would hit return on the keyboard>
#
# In [3]: def supportFunction(x,y,z):
# 	....: 	print 'in supportFunction(x,y,z)'
# 	....: 	print 'you gave me ',x,y,z
# 	....: 	V = []
# 	....: 	for i in range(0,z):
# 	....: 		V.append(x)
# 	....: 		V.append(y)
# 	....: 	print 'Just made a vector V = ', V
# 	....: 	print 'Let''s return it'
# 	....: 	return V
#   ....: <This is when you'd hit return>
#
# In [4]: ...and so on.





	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
#Just checking.