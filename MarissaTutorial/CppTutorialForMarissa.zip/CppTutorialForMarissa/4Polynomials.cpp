/***********************************************************************
 NOTE: if this looks funky, make it wider. I wrote some long lines 
 in this one. 
 
Let's take a minute to talk about doubles. I mean the C++ type
"double". Integers are nice, but there's no way our functions
"multiply2" and "power2" will work if we change the input 
and output to "double". Can you figure out why? 
See if you can figure out what will go wrong if you run 
the following code WITHOUT running it:


double multiplyDoubles(double x, double y){
    
    double output = 0;
    
    for (int i = 0; i < abs(y); i++){
        output = output + abs(x);
    }
    
    if(x < 0 && y >=0){
        //Then x*y is negative
        return -output;
    }
    else if(x >= 0 && y < 0){
        return -output;
    }
    else{
        return output;
    }
}

int main(){

	double e = 2.718281828;			//Euler's number (as in " f(x) = e^(x) ")
									// rounded to 10 significant digits

	double pi = 3.141592653;		//pi rounded to 10 sig digs


	//Compute "e-times-pi" 
	cout << "e * pi = " << multiplyDoubles(e,pi) << "     (our version)" << endl;
	cout << "e * pi = " << e*pi                  << "     (actual)" << endl;

return 0;
}


Try it and see what you get...AFTER you figure out what it'll probably print. 
(Don't think too long! Just think about it a little.)
 
*******************************************************************************
 
 
 
Of course it's not going to work becuase for( int i = 0; i < 3.141592653; i++)
will stop after 4 loops instead of...well...what...3 and .14159ths of a loop?


Clearly, we'd need somthing else to build proper "multiply" and "power" functions
up from addition. We won't be doing that (allthough we could!) because we want to 
head in a new direction. All you need to know is that the computer thinks of a 
double as a string of digits and an exponent. Just like scientific notation:

 //Make this wide------>------->------------>------------------->--------------------->to here
 
	  What you write							      What the computer thinks
	double pi = 3.14159;                        pi= 3.14159  *10^(1) == (3141590000000000, 1)
	double x  = 10.100110;                      x = 1.0100110*10^(2) == (1010011000000000, 2)
	double y  = 12345.67890123456789            y = 1.234...6*10^(4) == (1234567890123456, 4)

I think that on a 64-bit system, a double stores 16 significant digits, as above. 
I might be wrong. The point with "y" above is that it won't store the tail end 
(the last 3 digits, ...789) because that's more than 16 digits. It can't remember
that many.

The point now isn't to buld up a number system. That's already been done. 
From now on, we can use doubles, +, -, *, and /. They're "given." We'll 
also use the "pow" function provided by math.h. It's used exactly like "power" 
and "power2". You can run this in a scratch script:

		cout << "2^(3) = " << pow(2,3) << endl;

Now that we have all the operations we're familiar with from algrbra,
I wonder how we can write more exotic functions like sin(x), e^(x), and
so on. Functions that can't be built up with these algebraic operations
(+, -, *, /) are called TRANCENDENTAL FUNCTIONS. Yeah. You heard me right;
sin(x), e^(x), log(x) and our other friends from pre cal can NOT be 
constructed with multiplication, division, addition, and subtraction. 
Not with those things alone, anyway.


Fear not! It turns out that we can approximate most functions to ANY 
degree of precision (in most circumstances) by polynomials. The point of 
these next few tutorials will be to write our very own "mySin" function 
which is close enough to the real sin function that you'd never know the 
difference! To do this, we will need to learn Taylor's Theorem. 

We'll talk about Taylor's Theorem one-on-one. 
 
For what we'll be doing, it will be useful to have a function which 
evaluates a polynomial at a point. I've written a function called 
"polyVal" below. Take a look at it. The first thing you should notice
is that the first input it takes is a "vector<double>". Note that to 
use a "vector" we have to #include <vector>. Google "C++ vector" and see
what you can find.
 
Welcome back! Right now, we won't be thinking of vectors in a mathy 
sense. We'll just think of them as a convenient way of storing a string
of numbers. Suppose that our polynomial, P(x), is given by: 

	P(x) = 3 + 2*x + x^2.
	 
Then we can keep track of the coefficients (3, 2, and 1) in a vector 
like this:
 
vector<double> Coefficients;	//declare the container you'll use 
								//for the coefficients

double myCoeffs[] = {3, 2, 1}	//the coefficient values in order of
								//increasing power

Coefficients.assign(myCoeffs, myCoeffs + sizeof(myCoeffs)/sizeof(double));

The last one is tricky. We assign the values from myCoeffs (3,2,and 1) to
our vector "Coefficients". 
In the input to "assign()", we say to use all the 
values in myCoeffs from the begining to "sizeof(myCoeffs)/sizeof(double)".
But "sizeof(myCoeffs)/sizeof(double)" is equal to the number of doubles
we put into "myCoeffs[]." So this tricky little code is just a way of
making sure that we assign every value to our vector. 
 
There are many ways of putting values into a vector. If we have a known
polynomial (we know the coefficients a0, a1, ..., an), then this (below) is a way we
can put the individual coefficients in. When our coefficients are given by a 
formula, we will use a different method of filling vectors. But for now...

Let's say you wanted to assign the FIRST coefficient to another variable.
Call that variable "coef1". We would do this:
 
	double coef1 = Coefficients[0];		//zero is the FIRST index

Now, if we wanted to evaluate our polynomial, P(x), at x = 2, we would
have:

		P(x) = 3 + 2*x + x^2
		P(x) = Coefficients[0]*x^0 + Coefficients[1]*x^1 + Coefficients[2]*x^2 
		
		P(2) = Coefficients[0]*2^0 + Coefficients[1]*2^1 + Coefficients[2]*2^2 
		
		P(2) =        3*1           +        2*2         +       1*4
		
		P(2) = 11.

Say you wanted to evaluate the following polynomial at x = 3. 

	examplePoly(x) = -12 + 7x - 3x^3 + x^5.

First, we'd initialize our vector container

vector<double> coefVector;

Then we'd make a coefficient array:

double theseCoeffs[] = {-12, 7, 0, -3, 0, 1};
	//NOTE that we INCLUDED coefficients that are zero!!
	//That's because examplePoly(x)= -12 + 7x + 0x^2 - 3x^3 + 0x^4 + 1x^5

Then to get the value at x = 3 into some variable named "val_at_x3", we do:
 
double val_at_x3 = polyVal(theseCoeffs, 3);	

Now, the variable "val_at_x3" will equal examplePoly(3) = -12 + 7*3 -3*3^3 + 3^5.
 

Check out the code below. Figure out how it works. Play with it.
Try different values for x0 and the coefficients. You can make as many
or as few coefficients as you want since we made the function "polyVal"
GENERAL, so as to accept as many (or few) coefficient values as we want.

As you're working through the code below, you can do stuff like this 
to see what's going on step by step:

	double polyVal(vector<double> coeffs, double x0){
		double output = 0;
	
		for (int i = 0; i < coeffs.size(); i++){
			
			cout << endl << endl << "Loop number " << i + 1 << endl;
			
			cout << "coeffs[" << i << "] = " << coeffs[i] << endl;
			
			cout << x0 << " ^(" << i << ") = " << pow(x0, i) << endl;
			
			cout << "output before assignment = " << output << endl;
			
			
			//as long as you don't change this line, you're good!
			output += coeffs[i] * pow(x0, i);
			
			
			
			cout << "output after assignment = " << output << endl;
			
			cout << "End loop " << i + 1 << endl << endl;
		}
	
		return output;
	}

 
 
Once you get the hang of this, check out exercise5.cpp. Have fun!
***********************************************************************/



#include <iostream>
#include <math.h>
#include <vector>  //so we can use the "vector" container

using namespace std;


double polyVal(vector<double> coeffs, double x0){
	
	double output = 0;
	
	for (int i = 0; i < coeffs.size(); i++){
	
		output += coeffs[i] * pow(x0, i);
	}
	
	return output;
}



int main(){

	double x0 = 2;							//The point to evaluate the polynomial(s)
	
	vector<double> coefs1;					//coeffs for our 1st poly
	vector<double> coefs2;					//coeffs for our 2nd poly
	
	double myCoeffs[]  = { 3, 2, 1 };       //P1(x) = 3 + 2x +  x^2               (3 coeffs)
	double myCoeffs2[] = { 1, 2, 3, 4, 5 }; //P2(x) = 1 + 2x + 3x^2 + 4x^3 + 5x^5 (5 coeffs)
	
	//assign values to vectors
	coefs1.assign(myCoeffs, myCoeffs + sizeof(myCoeffs)/sizeof(double));
	coefs2.assign(myCoeffs2, myCoeffs2 + sizeof(myCoeffs2)/sizeof(double));
	
	cout << "Number of coefficients in P1(x) = " << coefs1.size() << endl;
	cout << "P1(" << x0 << ") = polyVal(coeffs, " << x0 << ") = " << polyVal(coefs1,x0) << endl;
	
	cout << "Number of coefficients in P2(x) = " << coefs2.size() << endl;
	cout << "P2(" << x0 << ") = polyVal(coeffs2, " << x0 << ") = " << polyVal(coefs2,x0) << endl;
	
	
	
	return 0;
}



