/***********************************************************************
 Exercise 4
 
 Make a new function, "power2" which extends your original
 function "power" to give the correct answer for negative integers.
 
 A word about negative exponents:
 
 We'll use "^" to denote exponents. So 2^(3) = 8. And we'll write
 "two-to-the-negative-three" as 2^(-3). And yes, 2^(-3) is
 "one-over-two-to-the-three", or 1/(2^3) = 1/8 = 0.125.
 
 But for that to work, we need decimals, not integers.
 We have two type options to represent a decimal (or rational) number
 since we can't use int for this. One is the type float. It stores 32
 bits of decimal information. The other type is double. It stores 64
 bits. If you want more precision, you have to pay the price with
 more memory. On our Arduino board, 64 bits is a bit too much to
 sacrifice on such a little board, so if you call something a double, it
 only stores it as a double anyway. We'll just use double as our output
 for "power2" and, okay, we can use the divide operator, "/"    ;-) 
 
 When you get done, go to 4Polynomials.cpp
 **********************************************************************/

#include <iostream>
#include <math.h>

using namespace std;


//Functions-------------------------------


//myHelloFunction: says hello
void myHelloFunction(){
    cout << "Hello World!" << endl;
}


//power2: fixes power!
double power2(int x, int y){
	
	double output;
	
	//your code
	
	return output;
}

int main(){
	
	myHelloFunction();
	
	
	
	return 0;
}
