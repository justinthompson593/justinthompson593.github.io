/***********************************************************************
 Exercise 2
 1. Verify that this runs, then delete all myHelloFunction stuff.
 
 2. Search online to find the maximum and minimum values for the 
    types "int" and "long" in C++. (Googling "C++ type long" may 
    be useful)
 
 3. Copy and paste your "multiply" function from exercise1.cpp into
    this file's Functions section.
 
 3. In the Functions section, find "power(int base, int exponent){..."
    and write code to make power return the value of base^(exponent).
    So power(2,3) should return 8 since 2^(3) = 2*2*2 = 8. 
    Again, you can NOT use the "*" operator. Oh, and use
    what you found in 2. to justify (to yourself) why our output type 
    is "long" instead of "int".
 
 4. In main, uncomment block 1 (as in exercise1.cpp), read it, 
	build it, run it.
 
 5. In main, change the value of "y" to zero. Build & run.
 
 6. Change the value of "y" to -3. Build & run. Move on to exercise3.cpp
 **********************************************************************/

#include <iostream>

using namespace std;


//Functions-------------------------------

//myHelloFunction: says hello
void myHelloFunction(){
    cout << "Hello World!" << endl;
}



//your mulitply function goes here



//power(base,exp): returns base^(exp)
long power(int base, int exponent){
    long output;
    
    //Your code goes here
    
    return output;
}
//end Functions-------------------------------


int main(){
    
    myHelloFunction();
    
    
    
    
    
    
    //testing for part 4
	/* block 1
	//Variables
    int x = 2;
    int y = 3;
    
    cout << x << " * " << y << " = " << multiply(x,y) << endl;
    cout << x << " ^(" << y << ") = " << power(x,y) << endl;
    */ //end block 1
    
    
    return 0;
}














