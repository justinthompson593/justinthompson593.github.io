/***********************************************************************
 Exercise 3
 
 Write code for "multiply2" defined below by:
 
 1. Identify what's causing the problem in "multiply"
 
 2. Fix it by considering that:
  
	a. one of these (and others like it) may be helpful.
	
		if(inputNumber > something){//your code here};
		if(inputNumber == something){//your code here};
		if(inputNumber < something){//your code here};
	
		If you want to get fancy, you can do something like
		if(inputNumber1 < sumpthin || inputNumber2 == sumpthinElse){};
		or some combination of =='s, ||'s, and &&'s (look up online!).
		Also, look up the C++ abs() function online. 
		As you'd expect, 3 = abs(-3). This function might be handy.
		It's definition lives in a header called "math.h". To use it,
		we have to #include it as we have in this file.
		
	b. by throwing a minus, "-", in front of something, you can make
	   it negative. So, if
	   
		int a = 3;
		
		And if
		
		int b = -a;
		
		Then b equals negative three in the computer.

It goes without saying that you can't use "*"!
When you're done, move on to exercise4.cpp 
 **********************************************************************/

#include <iostream>
#include <math.h>

using namespace std;


//Functions-------------------------------


//myHelloFunction: says hello
void myHelloFunction(){
    cout << "Hello World!" << endl;
}


//multiply2: fixes multiply!
int multiply2(int x, int y){
	
	int output;
	
	//your code
	
	return output;
}

int main(){
	
	myHelloFunction();
	
	
	
	return 0;
}


















