/***********************************************************
 * Exercise 6
 * 
 * Pattern recognition is arguably one of the things we humans
 * do which makes us human. Given a function f, we take a bunch of 
 * derivatives, f', f'', f''', ... and try to find patterns when we
 * evaluate these derivatives at some x0. Often times, we run into 
 * simple patterns like this:
 * 
 * f(x0)    = someNumber
 * f'(x0)   = anotherNumber
 * f''(x0)  = someNumber
 * f'''(x0) = anotherNumber
 * f(4)(x0) = someNumber
 * f(5)(x0) = anotherNumber
 * f(6)(x0) = someNumber
 * f(7)(x0) = anotherNumber
 * 
 * If we can code that pattern up, then we can...well...do anything.
 * Approximating phenomena mathematically is at the heart of scientific
 * research; without the numbers to back up your claims, you got nothin.
 * 
 * Recall Taylor's theorem. Choosing x0 = 0 gives us: 
 * 
 * Pn(x) = a0 + a1x + a2x^2 + ... + anx^n
 * 
 * 		 = f(0) + f'(0)x + (f''(0)/2!)x^2 + ... + (fn(0)/n!)x^n
 * 
 * 	 	 = Sum{i=[0,n]}(f^(i)(0)/i!)x^i       //don't worry bout this un
 * 
 *       = for (int i = 0; i < n; i++){
				P += (nthDerivativeEvaluatedAt_x[i]/factorial(i)) * pow(x,i);
		   }
 * 
 * 			This last loop can easily be used in a function.
 * 
 * This leads to a natural setup which will work for ANY collection of
 * coefficients, just as long as we can write code which can compute the 
 * pattern we observe when we evaluate these derivatives at some x0. 
 * This will be a HUGE theme in calculus, analysis, and beyond. 
 * In this exercise, I'll give you a simple pattern of values and have 
 * you print the pattern to screen. For instance, suppose I'd been given
 * a function, f(x). I took n derivatives, wrote 'em down, then I evaluated
 * each one at x0 = 0. Say that this is what I got:
 * 
 * f(x0)    = 1
 * f'(x0)   = 3
 * f''(x0)  = 5
 * f'''(x0) = 7
 * f(4)(x0) = 9
 * f(5)(x0) = 11
 * f(6)(x0) = 13
 * f(7)(x0) = 15
 * 
 * Okay. So I'm thinking, "Easy. It's just the odd numbers." But I'm also
 * thinking, "I know I'm going to put this in a 'for' loop. I'm going to 
 * have my counter 'i' since I'll type 'for(int i = 0;...'. On each loop, 
 * i is going to change automatically. I can USE that to help me out." 
 * And I'm also going to use a handy trick I learned in a proof writing 
 * class that you'll now have in your toolkit too. It's this:
 * 
 * since i   goes through 0, 1, 2, 3, 4,...
 * 
 * then 2*i  goes through 0, 2, 4, 6, 8,...
 * 
 * and 2*i+1 goes through 1, 3, 5, 7, 9,...   (so simple, and SO useful)
 * 
 * 
 * I just want to check that I'm calculating it right, so I wrote a 
 * couple of simple functions to test out. Read through the code below
 * to finish up my train of thought. Start at main() and read line by line,
 * following the variables through predict what the output will be. Then 
 * build & run.  
 * 
 * Once you got that down, suppose you took a bunch of derivatives, 
 * evaluated them at x0 = 0, and found that
 * 
 * f(x0)    = 2
 * f'(x0)   = 0
 * f''(x0)  = 4
 * f'''(x0) = 0
 * f(4)(x0) = 6
 * f(5)(x0) = 0
 * f(6)(x0) = 8
 * f(7)(x0) = 0
 *          ...and so on 	 
 * 
 * Comment out my code inside loadNthDeriv, and write your own to 
 * match your data above. Please feel free to use ALL the tricks you 
 * have up your sleeve. When it runs, go into main and change the
 * value of "const int n" to something else. Build & run.
 * 
 * 		NOTE: remember that the way we're going to do polynomials, we actually
 * 			  have to include the zeros in our vector! 
 ***********************************************************/




#include <iostream>
#include <math.h>
#include <vector>
 
using namespace std;


//computes the values of f(0), f'(0), ..., that I found on paper
void loadNthDeriv(vector<double> &derivVector){
	
	for (int i = 0; i < derivVector.size(); i++){
		derivVector[i] = (double) 2*i + 1;
	}
	
}

//let's me check that loadNthDeriv works 
void printVector(const vector<double> V){
	
	for (int i = 0; i < V.size(); i++){
		cout << "V[" << i << "] = " << V[i] << endl;
	}
	
}

int main(){
	
	
	
	const int n = 10; //max number of coefficients for poly approximation
	
	vector<double> nthDerivAtx0(n);	//a container for the values we're writing a formula for
									//       (I know my grammar was terrible here)
									//By putting "n" in () after the name, we're telling 
									//the computer that we're putting 10 things in there.
	
	loadNthDeriv(nthDerivAtx0);
	printVector(nthDerivAtx0);
	
	
	return 0;
}
