/***********************************************************************
 Exercise 5
 
 Go to http://www.learncpp.com/cpp-tutorial/71-function-parameters-and-arguments/
 
 Use this file to work through the examples in 7.1 through 7.3.
  
 I hope this doesn't seem like a cop out. These are just REALLY
 GOOD tutorials!! I copeid and pasted the first bit from 7.2 below somewhere.
 You may have to search through everything else that's below.  
 Comment, cut, paste, and whatever. Have fun with the tutorial.
 
 When you're done playing, check out the function makeHarmonicCoeffs(). 
 In main, get rid the comments on comment block 1, run it and check out
 the output. The first thing we do in comment block 1 is 
	vector<double> V(10);
 This command initializes a vector of doubles with 10 entries. Then when
 we throw V into makeHarmonicCoeffs(&V), the function assigns the 10 values
 to our vector V. See what happens when we change from
	vector<double> V(10);
 to 
	vector<double> V(20);
 Since we made makeHarmonicCoeffs() to accept a vector of ANY length, it
 should be filled with the values {1, 1, 1/2, 1/3,...} so that your output
 should be:
 
	V(0)  = 1
	V(1)  = 1
	V(2)  = 0.5
	V(3)  = 0.33333
	...
	V(19) = 0.0526316 
	 
 Find the empty function "Factorial." A description is provided. Write 
 code to make "Factorial" do what the description says. After that, do 
 the same for the function "makeExponentialCoeffs." Once you have that 
 done, uncomment comment block 2 and run it. If everything went right, 
 you should get
 
	V2(0)  = 1
	V2(1)  = 1
	V2(2)  = 0.5
	V2(3)  = 0.166667
	V2(4)  = 0.0416667
	...
	V2(9)  = 2.75573e-06
 
 
 When you're done, move on to 5Approximation.cpp
 **********************************************************************/

#include <iostream>
#include <math.h>
#include <vector>
using namespace std;




/*****************************************
 * FUNCTION:	polyVal(coeffs,x0)
 * INPUTS:		coeffs = (vector<double>) coefficients of polynomial, P 
 * 				x0     =    (double)      evaluation point
 * 
 * OUTPUT:		P(x0)  =    (double)      value of polynomial at x0
 * 
 * P(x0) = coeffs[0]*x0^(0) + coeffs[1]*x0^(1) + ... + coeffs[n]*x0^(n)
 *****************************************/
double polyVal(vector<double> coeffs, double x0){
	
	double output = 0;
	
	for (int i = 0; i < coeffs.size(); i++){
	
		output += coeffs[i] * pow(x0, i);
	}
	
	return output;
}



/***********************************************************************
 * FUNCTION:	makeHarmonicCoeffs(&myVector)
 * INPUTS:		myVector = (vector<double> &) 
 * DESCRIPTION:
 * 	Assigns values of myVector like this:
 * 		myVector[0] = 1
 * 		myVector[1] = 1/2
 * 		myVector[3] = 1/3  
 * 		...
 * 		myVector[N] = 1/N
 *
 * This sequence (1, 1/2, 1/3, 1/4,..., 1/N,...) is known as 
 * the harmonic sequnce. 
 * 
 * Fun fact:
 * 1 + 1 + 1/2 + 1/3 + ... + 1/n   + and so on will "blow up" to infinity whereas
 * 1 + 1 + 1/2 + 1/4 + ... + 1/2^n + ... = 2. 
 * 
 * Anyway, the point of this is to be able to construct a vector of
 * values (NOTE: values given by a formula, 1/N) which can be used as 
 * coefficients later. 
 * 
 * If V is your input to this function, then after
 * it finishes, we can use V in polyVal to give us
 * 
 * P(x) = 1 + x + (1/2)x^2 + (1/3)x^3 + ... + (1/m)x^m   (m is the size of V)
 * 
 *   
 **********************************************************************/
void makeHarmonicCoeffs(vector<double> &myVector){
	
	int N = myVector.size();
	
	myVector[0] = 1;
	for (int i = 1; i < N; i++){
		myVector[i] = (double) 1 / i;
	}
	
}



/***********************************************************************
 * FUNCTION:	Factorial(n)
 * INPUT:		myVector = (int) n
 * OUTPUT:		n! = n*(n-1)*(n-2)*...*3*2*1 
 * 
 * 1   = Factorial(0) = 1
 * 1   = Factorial(1) = 1
 * 2   = Factorial(2) = 2*1
 * 6   = Factorial(3) = 3*2*1
 * 24  = Factorial(4) = 4*3*2*1
 * 120 = Factorial(5) = 5*4*3*2*1 ...and so on
 
 (Feel free to Google "factorial")
 **********************************************************************/
long Factorial(int n){
	
	long output = 1;
	
	//Your code here
	
	
	
	return output;
}




/***********************************************************************
 * FUNCTION:	makeExponentialCoeffs(&myVector)
 * INPUTS:		myVector = (vector<double> &) 
 * DESCRIPTION:
 * 	Assigns values of myVector like this:
 * 		myVector[0] = 1
 * 		myVector[1] = 1/2
 * 		myVector[3] = 1/6
 * 		myVector[4] = 1/24  
 * 		...
 * 		myVector[N] = 1/N!
 * If V is your input to this function, then after
 * it finishes, we can use V in polyVal to give us
 * 
 * P(x) = 1 + x + (1/2)x^2 + (1/6)x^3 + ... + (1/m!)x^m (m is the size of V)
 
 HINT: use makeHarmonicCoeffs as a guide!
 **********************************************************************/
void makeExponentialCoeffs(vector<double> &myVector){
	
	//your code here
	
}



void foo(int y)
{
    cout << "y = " << y << endl;
}


 
int main()
{
    foo(5); // first call
 
    int x = 6;
    foo(x); // second call
    foo(x+1); // third call
 
 
 
/*comment block 1
	vector<double> V(10);
	cout << "Loading V with harmonic coeffs..." << endl;
	makeHarmonicCoeffs(V);
	
	for(int j = 0; j < V.size(); j++){
		cout << "V(" << j << ") = " << V[j] << endl;
	}
*/ //end comment block 1



/* comment block 2
	 vector<double> V2(10);
	 cout << "Loading V2 with exponential coeffs..." << endl;
	 makeExponentialCoeffs(V2);
	 
	 for (int k = 0; k < V2.size(); k++){
		 cout << "V2(" << k << ") = " << V2[k] << endl; 
	 }
*/ //end comment block 2
	
 
 
    return 0;
}
