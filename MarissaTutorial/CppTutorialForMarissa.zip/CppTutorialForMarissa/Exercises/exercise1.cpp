/*
 Exercises 1 - 4
 
 
 Our goal with Exercises 1 - 4 is to build a power function (as in
 "b to the power x" ,so f(x) = b^(x)) WITHOUT using multiplication. 
 But to do that, we'll need to be able to write our own code to multiply!
 
 Suppose that we couldn't use the multiply operator, "*".
 That is, pretend that the computer doesn't recognize the
 statement 4*3. Let's write a function which can
 multiply for us.
 
 Let's keep in mind that multiplication is just addition, but done
 over and over. For instance,
 
 4*3 = 4*( 1 + 1 + 1 ) = 4 + 4 + 4 = 12
 
 We can use all kinds of loops to do this repetitive addition,
 but I think a "for" loop is the best choice.
 
 */




/******************************************************************
 Exercise 1
 1. Verify that this runs, then delete all myHelloFunction
    stuff.
 
 2. Read from "#include..." until it says to go back to 3.
 
 3. In main(), uncomment the first block under "Variables" by deleting
    the line "/* comment block 1------" and the deleting line
    "*?//end comment block 1---". 
    Then build, run, play, understand, enjoy.
 
 4. Find the empty function "int multiply" just above main.
    Write your own code where it says "//Your code goes here" to make
    a function which returns the product of the two variables. You are
    not allowed to use the "*" operator. Use "multiplyBy2" and 
    "multiplyBy3" as guides. While writing your function, you can have
    something like "cout << "2*3 = " << mulitply(2,3) << endl;" written
    in main so that you can build & run to check AS you construct it.
    Just like how we had "myHelloFunction()" in main.
    If you were to do that now with nothing in it, it'll just return the 
    default "long" which should be zero. As you add lines, you can build 
    & run to check along the way.
 
 5. Check that your code works by uncommenting block 2 in main under
    "//Test your code". Build and run it to check. Then change the values
    of VariableOne and Two in main to your two favorite integers to test
    your code again. Once it works, move on to exercise2.cpp
******************************************************************/

#include <iostream>

using namespace std;


//Functions-------------------------------

//myHelloFunction: says hello
void myHelloFunction(){
    cout << "Hello World!" << endl;
}


//multiplyBy2(int input): returns input multiplied by 2
int multiplyBy2(int numToMult){
    
    //We need to return something
    //Let's call it output
    int output = 0; //Zero because we're adding. (You'll see.) We'll use the
                    //ADDITIVE identity, which is zero.

    
    //This executes what is inside these, {}, two times
    for (int i = 0; i < 2; i++){
        
        output = output + numToMult;
    }   //note that we didn't use the "counter" i in the loop.
        //That's cool. Use it if you need it.
    
    /*First, this loop reads this
     output = output + numToMult;  the statement in the loop says this.
     But we told the computer that
     output = 0. So,
     
     
     output =   0    + numToMult;  it assigns "numToMult" to the variable
     "output" using the value in memory. Now the
     computer thinks output = numToMult.
     
     
     Now we go back to the top of the loop
     output = output + numToMult;    this time, output = numToMult, so
     
     
     output = numToMult + numToMult;
     
     
     Now, output = numToMult + numToMult = numToMult*( 1 + 1 ) = numToMult*2
     That's what we want to return!                                               */
    
    return output;
}



//But the cool thing is that if we wanted to do that 3 times,
//it's as easy as copying, pasting, and changing the "2"
//in the for statement to a "3". Check it out.

//multiplyBy3(int input): returns input multiplied by 3
int multiplyBy3(int numToMult){
    
    int output = 0;
    for (int i = 0; i < 3; i++){
        output = output + numToMult;
    }
    return output;
}

/*comment block

 Note that the names "numToMult" and "output" can be the same 
 in the two different functions because everything
 we declare inside () and { } after the function name
 get destroyed as soon as the function returns. That is, we declared
 "output" in multiplyBy2. But after multiplyBy2 returns, the variable
 "output" is destroyed and it's free to use again.


 Here's your intro to abstraction. After these first two
 functions, it's not a too hard to see how to make a
 "multiplybyN" function for any integer N. (You just put N
 where we put 3 above!) But we don't know ahead of time
 what N is going to be. We could make millions and millions of
 functions; "multiplyBy710928(int numToMult)",
 "multiplyBy710929(int numToMult)", ... but that's absurd. 
 Instead, we can make a function with
 2 input values. For instance, if I wanted a function which
 takes a date and a time and returns your appointments at
 that time. An imaginary one could be set up like this:
 
 This function returns an "appointment" which is a, say,
 text document or note you made in a calendar. We'd like a
 function which gives us those notes or "appointments" on
 a given day and at a given time:
 
 //getMyAppointment: returns an "appointment" structure
 appointment getMyAppointment(int day, int time){
 
    appointment output; //declare some "appointment" to return
 
    SomeCrazyObject.OpenCalendar(); //some function which opens
                                    //an imaginary calendar...
 
    //Then there'd be some way to assign
    output = SomeCrazyObject.AccessAppointmentOnDayTime(day,time);
 }
 
 
 This example is a little silly, but the point is that
 all you have to do to get a second variable in a function is to
 declare it in the parenthesis, (), like this:
 
 
 int myFunction(int variableOne, int variableTwo){
 
        //Your code goes here!
 }
 
 */ //end comment block



//Now that you've read to here, go back to the top and do 3.


//This is for part 4
//multiply: returns the product of var1 and var2 without using "*"
int multiply(int variable1, int variable2){
    
    int output;     //to be returned
                    //HINT: you may want to initialize this
                    //to some value. See functions above.
    
    
    //Your code goes here
    
    
    return output;
}
//end Functions-------------------------------



int main(){
    
    //just sayin' hey!
    myHelloFunction();
    
    //Variables

    //for part 3
  /* comment block 1------------
    int variableOne = 2;
    int variableTwo = 3;
    
    cout << "variableOne = " << variableOne << endl;
    cout << "variableTwo = " << variableTwo << endl;
    cout << "variableOne * 2 = " << multiplyBy2(variableOne) << endl;
    cout << "variableTwo * 2 = " << multiplyBy2(variableTwo) << endl;
    cout << "variableOne * 3 = " << multiplyBy3(variableOne) << endl;
    cout << "variableTwo * 3 = " << multiplyBy3(variableTwo) << endl; 
  */ //end comment block 1 ------
    
    
    //Test your code
  /* comment block 2------------
    cout << variableOne << " * " << variableTwo = " << multiply(variableOne, variableTwo) << endl;
    cout << variableTwo << " * " << variableOne = " << multiply(variableTwo, variableOne) << endl;
    
  */ //end comment block 2 ------
    
    
    
    return 0;
}






















