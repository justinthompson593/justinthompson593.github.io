
/*******************************************
 
 A word about this tutorial:
 
 This tutorial is not designed to be a 
 comprehensive introduction to C++. If 
 that's what you're looking for, let me 
 suggest the C++ tutorial at 
 
    http://www.learncpp.com
 
 
 This tutorial is designed to get you 
 familiar with general programming 
 concepts by walkning you through a 
 mathematical mini-project.
 
 Just follow along, and you'll be told
 which file to open next and what to 
 do with it. 
 
 Have fun!
 
 *******************************************/




/* FUNCTIONS

 I realized that our use of the word "loop" may be a little unclear.
 I mean, Arduino uses a function named "loop" into which I've told
 you we can write loops which are evaluated every time "loop" loops
 through its next loop. Huh?
 
 Think about it from the computer's perspective.
 
 A computer is going to read the code you write in a certain order. You
 need to be able to track that order so that you can find bugs later.
 (Oh yes, there will be bugs!) A C++ program begins with a function called
 "main." It usually looks like this (below) and the computer will read it,
 as you will, line by line.   ;-)
 
 
 int main(){
 
 This is where your code would go.
 Suppose your program loaded an image file right here.
 If that file has been deleted, your program can't finish.
 We'd have to stop, and we'd want to know what went wrong.
 
 Let's use the integer 1 to mean that the image couldn't be found.
 If this happens, you may have a bool named "noImage"
 or whatever which is set to true since there was
 no image found.
 
 noImage = true;
 
 Then we'd do something like this:
 
 if(noImage){  //since this is true, we enter the {}'s.
 return 1;  //Note that if you return, everything below here
 //isn't read. We jump to the very end of main.
 //Then your program is done.
 }
 
 But if noImage is false, we skip everything in the
 curly brackets and start reading here.
 
 Then say that our program is supposed to enhance the
 colors of this image (adjust hue, brightness, etc).
 Maybe the original image has to be bright enough for
 the computer to read. So maybe the image object (let's
 call it "Image") has a property called "brightness."
 Usually, to access a property, you usually see something
 like this "Image.brightness" Something like this is often
 used:
 
 if( Image.brightness < tolerance ){
 return 2;
 }
 
 But if the image is brighter than our "tolerance," then
 we can do our modifications. But that's probably a long,
 long, long intensive process. I mean, if we want to change
 just the hue, we have to change the values for, say, 1
 million pixels. For each of those, we have to modify the
 red, green, and blue channels to a certain...zzzZZZ. Long
 story short, there are LOTS of operations we need to perform.
 Ultimately, all of those commands can be surrounded by curly
 brackets, {}, and we can give that group of commands a name.
 Let's call it "processImage."
 
 We have a decision to make. This function can be a "function" in
 the precise mathematical sense: "A function gives ya an output
 when ya give it an input." Or we can choose to only execute this
 group of commands and that's all.
 
 Check out this function:

 void myHelloFunction(void){
    
    //say hi!
    cout << "Hello!" << endl;

}

 
 Before the function name, we type what type the output will be.
 The "void" before myHelloFunction means that this function does
 not "return."
 
 Note that myHelloFunction was declared as
 void myHelloFunction(void)
 That second "void" means that it doesn't take an input. This is
 the type of function which simply executes whatever is in the {}'s
 as though it's wherever you write "myHelloFunction();" in your
 code. So if I'd defined "myHelloFunction" somewhere (we'll get to that)
 then I can just write:
 
 myHelloFunction();
 
 And it's exactly the same as writing:
 
 //say hi!
 cout << "Hello!" << endl;
 
 
 That's how the computer sees it. It's much more convenient to break this into
 smaller pieces. Inside "main()" above, we did 3 major things:
 1. We load the Image
 2. We check that it's not too bright
 3. We do our image processing stuff (which, in itself, involves
 many functions in functions in ...
 
 We can gather everything we need from main() in order to load the image.
 Pretending that my writing it above were actual code, we could cut and paste
 everything and put it in a function like this:
 
 
 
 loadImage(string imageName){
 
 This is where your code would go.
 Suppose your program loaded an image file right here.
 If that file has been deleted, your program can't finish.
 We'd have to stop, and we'd want to know what went wrong.
 
 Let's use the value "false" to mean that the image couldn't be found.
 If this happens, you may have a bool named "noImage"
 or whatever which is set to true since there was
 no image found.
 
 noImage = true;
 
 Then we'd do something like this:
 
 }
 
 
 
 
 But we need to decide to make this a void function (a function which 
 doesn't return a value), or if we want it to output something. 
 Let's go ahead and make loadImage the return
 value of noImage. We could change it like this:
 
 
 
 **Put "bool" in front of the definition
 
 bool loadImage(string imageName){
 
 This is where your code would go.
 Suppose your program loaded an image file right here.
 If that file has been deleted, your program can't finish.
 We'd have to stop, and we'd want to know what went wrong.
 
 Let's use the value "false" to mean that the image couldn't be found.
 If this happens, you may have a bool named "noImage"
 or whatever which is set to true since there was
 no image found.
 
 
    if (theImageLoadedSuccessfully){
        return true;
    }
    else{
        return false;
    }
 
 
 }
 
 
 
 Then back in main(), we'd have:
 
 
 
 
 int main(){
 
	if(!loadImage("MyKittyPicture.jpg")){
		return 1;
	};
 
 ...
 
 
 }
 
 
 
 The "!" before loadImage negates whatever is after it. To
 see what's going on, read it like the composition of functions
 (i.e. f( g( h(x) ) ) and so on). 
 The innermost thing is a string with value
 MyKittyPicture.jpg. We tell our function loadImage to load
 this picture. If it was successful, we told the function to
 return true. That is, the computer first EXECUTES loadImage,
 does everything we've told it to, and THEN, the symbol we wrote
 after !, that is, "loadImage("MyKittyPicture.jpg")" itself
 BECOMES a bool with value "true". (Ditto, if it didn't load, only
 the symbol would be "false".) 
 
 The computer reads, "if( STUFF )," Then it evaluates STUFF:
 
 STUFF = !SOMETHING
 
 Then it evaluates SOMETHING
 
 SOMETHING = loadImage("MyKittyPicture.jpg")
 
 So it says, "well I'd better run loadImage("MyKittyPicture.jpg")," 
 which it does line by line. After successfully loading the .jpg and 
 completing all the lines in the definition of the function, the
 SOMETHING above evaluates to "true". That is, the computer thinks
 
 SOMETHING = true.
 
 Now, if(STUFF) = if(!SOMETHING) = if(!true). So in main, we have:
 
 
 
 
 int main(){
 
	if(!true){
		return 1;
	}
 ...
 
 }
 
 
 
 
 
 But "!true" (read "not true"), is not true. If something is not true, it is false. 
 Get it? So we have,
 
 int main(){
 
	if(false){  //since false isn't true, we don't enter this loop
		return 1;
	}
 ...
 
 }
 
 And now our function "loadImage()" has run successfully, our Kitty image
 is loaded and we can continue on in main.
 
 Doing this for the other two big steps, our program would look like this:
 
 
 
 
 
 //------EXAMPLE SCRIPT-----------
 
 //Global Variables*****
 string fileName = "MyKittyPicture.jpg";    //Name of the file you wish to process
 Parameters imageProcessingParameters;      //image processing params
 int threshold = 1000;                      //some measure of brightness that's too bright
 
 //Functions*****
 
 //description of function
 bool loadImage(string imageName){
 
    Blah blah blah
 
    Stuff stuff stuff
 
    return somethin;
 }
 
 
 
 //description of func
 int checkBrightness(void){
	checkIt();
 }
 
 
 
 //description of func
 Image processImage(Parameters theseParams){
	doAllThatCrazyStuffWith(theseParams);
	doItAgainForFun();
	loadCurrentImageInMemory(doIt(now));
	makeCurrentImagePurty();
 
	...
 
	return theImageYouAskedForButDoneUpAllNice;
 }
 
 
 
 //MAIN*****
 
 
 int main(){
 
	if(!loadImage(fileName)){//filename is a global var, so we can use it here
		return 1;
	}
 
    //if main returns 1, we'll know the program failed because
    //it couldn't load the image
 
	if(checkBrightness() < threshold){
		return 2;
	}
 
    //if main returns 2, we'll know that the picture was "too bright"
    //to process
 
	Image myEnhancedKittyPicture = prcessImage(imageProcessingParameters); //same with imgProcParms here
 
	if(Print(myEnhancedKittyPicture)){
		//then my pic printed to screen so
		return 0;       //all is well in the world
 
 
    //if main returns 0, everything went well!
 
 
	}
	else{
		return 3;       //sumpthins wrong
 
 
    //if main returns 3, the problems must have been with the Print() 
    //function. Hopefully you've done the same thing with Print() so 
    //that you can trace what went wrong!
 
 
	}
 
 }
 
 
 
 
 
 
 
 //-----EXAMPLE SCRIPT--------
 
 
 
 
 
 
 
 
 Now main() is a lot prettier and the computer still reads the program
 in EXACTLY THE SAME ORDER. But here's where it gets cool:
 main is a function which takes processing parameters, a threshold, and
 a file name, and it prints an enhanced image to screen.
 
 We can simply RENAME main and have something like this:
 
 
 
 
 int printEnhancedImage(string myImageName, Parameters myParams, int thresh){
 
	if(!loadImage(myImageName)){       //filename is a global var, so we can use it here
		return 1;
	}
 
	if(checkBrightness() < thresh){
		return 2;
	}
 
	Image myEnhancedKittyPicture = prcessImage(myParams); //same with imgProcParms here
 
	if(Print(myEnhancedKittyPicture)){//then my pic printed to screen so
		return 0;       //all is well in the world
	}
	else{
		return 3;       //something went wrong
	}
 }
 
 
 

 
 Now we can use that along with our functions in another main() which
 does something else. And so on...

 
 Go on to 2ForLoops_IfStatements.cpp
 
 
 */

