/* 
 2FORLOOPS_IFSTATEMENTS
 
 Before we begin with some exercises, we need to understand what a "for loop"
 is. In C++, it's a way of doing some repetitive thing a certain number of times.
 The best way to get a feel for what loops do is to play with one. 

 
 This file is ready to be compiled and run. Compile and run this file right now. 
 If you need help doing that, check out the instructions in the "C++ Tutorial" section of this page:
 
 http://justinthompson593.github.io/Home/MarissaTutorial/index.html
 
 
 Before you do that, read through each line below and try to predict what the 
 output will be when you run this. It'll seem very cryptic at first; that's the 
 point! You'll have to read it, run it, change some numbers, run it, read it,
 add some extra lines to print, run it, change some numbers, run it...
 
 Do you see where I'm going with this? This is the best way to learn how to code.
 You MUST play with it and you MUST have fun. But more is true! By getting used to
 looking at someones code, reading it, running it, changing some things, 
 running it, ... , and so on, you learn new techniques, new languages, new ideas.
 

 */
 
//A word about comments. I realized that Marissa and I had already discussed them
//before she began. So here we go:

//This line begins with "//". Everything after it
//will not be read by the compiler. It's as though it doesn't exist.

/* You can also comment like this. Everything inside the "slash-stars"
 will not be read. I can't actually write the "slash-stars" in the "slash-stars"
 though. Hope that wasn't too confusing. */



#include <iostream>

using namespace std;

int main(){
 
    //Just making some space here at the top so
    //it's easy to find after you run it. A lot will be printed out, so you'll
    //need to
    cout << endl << endl << "********************************************" << endl;
                    cout << "           SCROLL BACK UP TO HERE           " << endl;
                    cout << "********************************************" << endl;

    //This is where you'll play with different values
    //It's nice to have them all up here in one convenient place
    int numberOfLoops = 3;
 
    cout << "We are inside main() and we've decided" << endl;
    cout << "to print " << numberOfLoops << " loops." << endl;
    
    //Printing some space to make it look nice
    cout << endl << endl;

 
	int loopCount = 1; //we will use this for reference in the loop below
 
	for(int counter = 0; counter < numberOfLoops; counter++){
		
        cout << "This is loop number " << loopCount << endl;

        cout << "Note that counter = " << counter << endl;
        
        cout << "and numberOfLoops is " << numberOfLoops << "." << endl;
        
        cout << "We entered the loop because" << endl;
        
        cout <<  "counter = " << counter << " < " << numberOfLoops << " = numberOfLoops" << endl;
        
        cout << "That's the condition to enter this loop!" << endl;
 
        cout << "Note that counter = " << counter << " because we initialized it that way" << endl;
        
        cout << "(i.e., we wrote int counter = 0)" << endl;
 
        cout << "and we're only on loop number " << loopCount << endl;

        cout << "After this round is done, 'counter++' means" << endl;
        
        cout << "that we increment 'counter' by one." << endl;
        
        cout << "Let's say that we're done writing whatever " << endl;
        
        cout << "code needs to go in this for loop." << endl;
        
        cout << "So let's increment 'loopCount'" << endl;
        
        loopCount++;    //that's how you increment by 1
                        //you can decrement by 1 by writing 'loopCount--'
                        //In fact, there are a lot of intuitive things like that in C++
                        //If you think, "well, '++' adds 1, I wonder if '--'
                        //subtracts 1," go ahead and try it! Change the code and run it.
                        //Worst-case scenario: your computer catches on fire.
        
        cout << "Now loopCount = " << loopCount << " and we go into the next one" << endl;
        
        cout << "as long as " << counter + 1 << " < " << numberOfLoops << endl;
        
        //Print some empty lines so each loop is easier on the eyes
        cout << endl << endl;

	}
     
     cout << "We didn't enter the loop this time because we've already " << endl;
     cout << "done a total of " << numberOfLoops << " loops." << endl;
 

    //Making space for the next section
    cout << endl << endl;
 

//These are also parameters you'll play with.
int number1 = 2;
int number2 = 2;

//They'll be used in the loop below to define how many times the loops are
//executed. Note that below, there's a loop inside of a loop. Yep, you
//can do that! Just notice that we used different variable names (i and j)
//as the counters.

//Use the loop above as an example to decypher what's going on here:
    for(int i = 0; i < number1; i++){
 
        //understand what happens here
        cout << "Delete this line. Your code goes in this space." << endl;
 
        for(int j = 0; j < number2; j++){
 
            //understand what happens here
            cout << "Delete this line. Your code goes in this space." << endl;
        }
 
        //understand what happens here
        cout << "Delete this line. Your code goes in this space." << endl;
    }
    
//Read the commented section below:
        
        /*
         
         IF STATEMENTS
         
         Make sure you can follow along with this part.
         Your understanding of this will be needed to
         do the exercises.
         
         
         if(input){
         
         }
         
         Anything that goes in the "input" has to evaluate
         to a bool (true or false). This may be some bool you've
         defined, like this:
         
         bool onOffSwitch = false;   //Makes sure things are off at startup
         
         if(onOffSwitch){
         doThisStuff(); //do that stuff
         }
         
         It could be a logical statement, like 1 < x, x == y, or 3.141 < pi || pi <= 3.15
         so that
         
         if(1 < x && x < 2){
         cout << x << endl;
         }
         
         will only print x if x is strictly greater than one AND x is strictly less than 2.
         
         
         And
         
         if(0 <= x || x == -1){
         cout << x << endl;
         }
         will print x if it is bigger than or equal to zero OR if x is -1.
         
         
         
         
         Usage 1:
         if(thisIsTrue){
         do this code here;
         }
         
         
         Usage 2:
         if(thisIsTrue){
         do what's in here
         }
         else{
         do what's in here
         }
         
         
         Usage 3:
         if(thisIsTrue){
         do this
         }
         else if(thatIsTrue){
         do that
         }
         else{
         do the other
         }
         
         ...
         
         Usage N:
         if(this1_isTrue){
         do thing 1;
         }
         else if(this2_isTrue){
         do thing 2;
         }
         ...
         }
         else if(this[N-1]_isTrue){
         do thing N-1;
         }
         else{
         do thing N;
         }
         
         
         PLAY AROUND with some different if statements. Try to
         predict with the outcome will be.
         
         Here's one possible setup. See if you can come up with your own.
         
         */
    
    
    //Making space for section below
    cout << endl << endl;
    
    
        int a = 2;
        int b = 3;
        
        if( a < b ){
            cout << "a was less than b" << endl;
        }
        else{
            cout << "a was not less than b" << endl;
        }
    
    //Making space
    cout << endl << endl;
        
        bool condition1 = true;
        bool condition2 = false;
        bool condition3 = true;
        
        if(condition1){
            if(condition2){
                if(condition3){
                    //put stuff in here
                }
            }
            else if(condition3){
                //I have no idea what I'm doing
            }
            //Anything will be better than this!
        }
        

    
    
    cout << "Now you'll have to scroll ALL the way to the VERY top." << endl;
    cout << "...by the way, don't make your loop numbers too big!" << endl << endl;

    //So run this guy and PLAY AROUND until you feel comfortable.
    //Then move on to 3Setup.cpp
    
        return 0; //don't worry about this guy right now ;-)
}

