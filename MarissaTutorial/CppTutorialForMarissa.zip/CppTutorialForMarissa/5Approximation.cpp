#include <iostream>
#include <math.h>
#include <vector>
#include <limits>

using namespace std;
/***************************************************************
 * 
 * 
 * Below, you'll find the code I wrote for factorial() and 
 * makeExponentialCoeffs(). See how it differs from the code you
 * wrote in Exercise 5. If there's something you don't understand 
 * (like "while(x > y)...") ask me about it or Google it ;-). 
 * 
 * After you're ABSOLUTELY sure that your factorial() and 
 * makeExponentialCoeffs() functions are accurate, comment out
 * my code for the functions and put your own in. 
 * 
 * Read through main() to see what we're going to print.
 * It's the familiar setup. We had f(x) = e^x, took all it's derivatives
 * and evaluated at zero to make our poly approximation. Here, we'll see
 * what happens when we use more and more coefficients in our polynomial
 * approximation Pn(x). 
 * When this runs, we start by writing "const int n = 10;"
 * This is the max number of coefficients we'll use in Pn. First, we'll 
 * see the zeroth order approximation
 * 
 * P0(x) = 1               (pretty bad approximation of e^x)
 * 
 * Then it will evaluate P0(x) at the point x0 = 1, so that
 * 
 * P0(1) = 1               (really bad approximation of e^x)
 * 
 * Then it calculates f(1) = e^(1) = 2.718281828459045...
 * 
 * Then it gives us a measure of just how bad the 0th order 
 * approximation by calculating the difference between the 
 * actual function evaluated at x0 = 1
 * 
 * f(x0) = f(1) = e^(1)
 * 
 * and our approximation,
 * 
 * P0(x0) = P0(1) = 1
 * 
 * and gives us the difference, 
 * 
 * error = f(x0) - P0(x0) = 2.7182... - 1 = 1.718281828...
 * 
 * Then it loops back to make the first order poly approximation, P1(x). 
 * It prints it all nice so you can read it, then it calculates the 
 * error, f(x0) - P1(x0).
 * 
 * You'll notice that the error decreases as the order of the approximation 
 * gets larger. 
 * 
 * Now build & run this guy. Play with the value of "n" in main to see how
 * good we can get it.  
 ***************************************************************/


//Functions-------------------------------
/*****************************************
 * FUNCTION:	polyVal(coeffs,x0)
 * INPUTS:		coeffs = (vector<double>) coefficients of polynomial, 
 * 				x0     =    (double)      evaluation point
 * 
 * OUTPUT:		            (double)      value of polynomial at x0
 * 
 * P(x0) = coeffs[0]*x0^(0) + coeffs[1]*x0^(1) + ... + coeffs[n]*x0^(n)
 *****************************************/
double polyVal(vector<double> coeffs, double x0){
	double output = 0;
	
	for (int i = 0; i < coeffs.size(); i++){
	
		output += coeffs[i] * pow(x0, i);
	}
	
	return output;
}



/*****************************************
 * FUNCTION:	factorial(n)
 * INPUT:		n = (int) must be >= 0  
 * 				
 * OUTPUT:		(long) n!
 * 
 * 0! = 1
 * 1! = 1
 * 2! = 2*1
 * 3! = 3*2*1
 * ...
 * n! = n * (n-1) * (n-2) *...* 2 * 1
 *****************************************/
long factorial(int n){
	long out = 1;
	
	//we don't want to mess with n itself. Use dummy variable 
	//to change in the loop so that we don't change n itself. 
	int idx = n;
	while( idx > 0 ){
		
		out *= idx;
		idx--;
		
	}
	
	return out;
}

/***********************************************************************
 * FUNCTION:	makeExponentialCoeffs(&myVector)
 * INPUTS:		myVector = (vector<double> &) Passed by reference
 * DESCRIPTION:
 * 	Assigns values of myVector like this:
 * 		myVector[0] = 1
 * 		myVector[1] = 1/2
 * 		myVector[3] = 1/6
 * 		myVector[4] = 1/24  
 * 		...
 * 		myVector[N] = 1/N!
 * If V is your input to this function, (i.e. makeExponentialCoeffs(V)),
 * then after it finishes, we can use V in polyVal to give us:
 * 
 * P(x) = 1 + x + (1/2!)x^2 + (1/3!)x^3 + ... + (1/m!)x^m (m is the size of V)
 
 HINT: use makeHarmonicCoeffs as a guide!
 **********************************************************************/
void makeExponentialCoeffs(vector<double> &myVector){
	
	for (int i = 0; i < myVector.size(); i++){
		myVector[i] = (double) 1 / factorial(i);
	}
	
}






int main(){
	


	//Choose the number of coefficients, to use for our approximation poly, 
	//      Pn(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
	int n = 10; 
	
	//choose the value of x0 at which we evaluate the poly
	//		Pn(x0) = a0 + a1*x0 + a2*x0^2 + ... + an*x0^n
	double x0 = 1; 	//we'll check out x0 = 1 since it's near our eval point, x0 = 0.
					//Don't want to go too far away...why?
	
	
	
	for (int i = 1; i < n; i++){
		cout << endl;
		
		cout << "************Making " <<  i - 1 << "th order polynomial approximation ************" << endl;
		
		
		
		vector<double> myCoeffs(i); //i determines number of coeffs we calculate
	
		makeExponentialCoeffs(myCoeffs);	
		
		cout << "P" << i -1 << "(x) =   ";
		for (int k = 0; k < myCoeffs.size(); k++){
			
			if( k == 0 ){
				cout.precision(15);
				cout << myCoeffs[k] << endl;
				continue;
			}
			
			cout << "        + " << myCoeffs[k] << "x^(" << k << ")" << endl;
		}
		cout << endl << endl;
		
		cout.precision(15);
		cout << "P" << i - 1 << "(" << x0 << ") = " << polyVal(myCoeffs,x0) << endl;
		cout << "e^(" << x0 << ") = " << exp(x0) << endl;
		
		cout << "Error = e^(" << x0 << ") - ";
		cout << "P" << i << "(" << x0 << ") = ";
		cout << exp(x0) - polyVal(myCoeffs,x0) << endl;
		cout << endl;
	}

	cout << "Machine precision: " << numeric_limits<double>::epsilon() << endl;
	cout << "Look this up!!" << endl;

	return 0;
}
