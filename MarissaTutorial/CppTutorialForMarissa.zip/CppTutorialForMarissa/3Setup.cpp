   /*

 ----------------------------------------------------------------------
 1. As you read along in the tutorial, I'll tell you to stop and do
 Exercise 1 or some range like Exercises 1 - 4. 
 
 If you're using an IDE, open exerciseX.cpp with it. You will be able to
 edit and run the file from your IDE.
 
 If you're doing this the fun way, open exerciseX.cpp in your favorite
 text editor (I'm partial to TextWrangler right now).
 

 ----------------------------------------------------------------------
 2. The file "exerciseX.cpp" will be runable as-is. I'll have each exerciseN.cpp file set up like this:
 
 
 
 *****************************************************
 Exercise X:
 Intro, Idea, etc...
 Instructions, etc...
 *****************************************************
 
 
 
 #include <iostream>
 #include <math.h>
 #include <other stuff if necessary>
 #include "someFile.h"
 
 using namespace std; //For easy in and out
 
 
 //Functions
 void myHelloFunction(){             //This will ALWAYS be here...read on
 cout << "Hello World!" << endl;
 }
 
 *** If there are other functions here, they will be commented out
 first. I'll instruct you when to uncomment them and what to
 do with them in the instructions. ***
 //possibleOtherFunctions(){
 //
 //     This one may already have code
 //
 //}
 
 //anotherFunction(){
 //
 //     This one may be blank for you to fill out.
 //
 //}
 
 
 //myFunction(variableOne,variableTwo){
 //
 //      This one may may also be blank
 //
 //}
 
 
 int main(){
 
 myHelloFunction();  //This will be here every time so that
 //you can test the exerciseX.cpp file.
 //Once you load the file, build and run
 //it to make sure it works. Every time,
 //the program should print "Hello World!"
 
 
 *** If there's anything else in main(), it will be commented out
 like it is below. ***
 
 
 //Some Variables we may need in exercieseX.cpp
 //int variableOne = 0;
 //int variableTwo = 1;
 
 
 //possibleOtherFunctions();
 //anotherFunction();
 //myFunction(variableOne, variableTwo);
 
 
 
 
 return 0;
 }
 
 
 ----------------------------------------------------------------------
 3. Build and run exercise1.cpp. Make sure that the output is correct:
 check that it only printed "Hello World!" and that your program
 finished with exit code 0. You can go ahead and DELETE both the definition
 of "myHelloFunction" and it's call in main. So, exerciseX.cpp would look
 like this:
 
 
 *****************************************************
 Exercise X:
 Intro, Idea, etc...
 Instructions, etc...
 *****************************************************
 
 
 
 #include <iostream>
 #include <math.h>
 #include <other stuff if necessary>
 #include "someFile.h"
 
 using namespace std; For easy in and out
 
 //Functions
 void myHelloFunction(){
 cout << "Hello World!" << endl;
 }
 
 //possibleOtherFunctions(){
 //
 //     This one may already have code
 //
 //}
 
 //anotherFunction(){
 //
 //     This one may be blank for you to fill out.
 //
 //}
 
 
 //myFunction(variableOne,variableTwo){
 //
 //      This one may may also be blank
 //
 //}
 
 
 
 int main(){
 
 //Some Variables we may need in exercieseX.cpp
 //int variableOne = 0;
 //int variableTwo = 1;
 
 //possibleOtherFunctions();
 //anotherFunction();
 //myFunction(variableOne, variableTwo);
 
 
 
 return 0;
 }
 
 
 Then you're ready to begin! Notice that I only deleted the stuff for
 myHelloFunction. EVERYTHING else stays as it is. Begin by following the
 instruction as the top. Each exercise is set up like this so you can make 
 sure there are no errors before you begin.
 
 In ../YourPath/CppTutorialForMarissa/Exercises, find exercise1.cpp and
 begin. Oh, and HAVE FUN!!!
 */


